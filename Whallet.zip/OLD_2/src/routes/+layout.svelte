<script>
	import '../styles/global.css';
</script>

<slot />
