<script>
	import Footer from '../components/layout/Footer.svelte';
	import Header from '../components/layout/Header.svelte';
	import '../styles/global.css';
</script>

<Header />
<slot />
<Footer />
