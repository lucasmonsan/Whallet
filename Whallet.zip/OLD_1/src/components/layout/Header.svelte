<script lang="ts">
</script>

<header>
	<h1>adicionar</h1>
</header>

<style>
	header {
		z-index: 5;
		position: fixed;
		top: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 4rem;
		background-color: var(--color-gray);
		box-shadow: var(--shadow-sm);
	}
</style>
