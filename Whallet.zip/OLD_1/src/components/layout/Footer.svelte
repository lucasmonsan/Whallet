<script lang="ts">
</script>

<footer>
	<h1>adicionar</h1>
</footer>

<style>
	footer {
		z-index: 5;
		position: fixed;
		bottom: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 4rem;
		opacity: 0.5;
		background-color: var(--color-gray);
		border-radius: 1rem 1rem 0 0;
		box-shadow: var(--shadow-sm);
	}
</style>
